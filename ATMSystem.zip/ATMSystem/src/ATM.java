import java.util.Scanner;

public class ATM {
    private BankAccount account;
    private Scanner scanner;

    public ATM(BankAccount account) {
        this.account = account;
        scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        System.out.println("\n=== ATM Menu ===");
        System.out.println("1. Check Balance");
        System.out.println("2. Deposit Money");
        System.out.println("3. Withdraw Money");
        System.out.println("4. Exit");
        System.out.print("Please select an option (1-4): ");
    }

    public void start() {
        boolean exit = false;
        while (!exit) {
            displayMenu();
            int choice = getUserChoice();
            switch (choice) {
                case 1:
                    checkBalance();
                    break;
                case 2:
                    depositMoney();
                    break;
                case 3:
                    withdrawMoney();
                    break;
                case 4:
                    System.out.println("Thank you for using the ATM. Goodbye!");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid selection. Please choose between 1-4.");
            }
        }
    }

    private int getUserChoice() {
        int choice = -1;
        try {
            choice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {

        }
        return choice;
    }

    private void checkBalance() {
        System.out.printf("Your current balance is: $%.2f%n", account.getBalance());
    }

    private void depositMoney() {
        System.out.print("Enter amount to deposit: $");
        double amount = getPositiveDouble();
        if (amount > 0) {
            account.deposit(amount);
        } else {
            System.out.println("Deposit failed. Amount must be positive.");
        }
    }

    private void withdrawMoney() {
        System.out.print("Enter amount to withdraw: $");
        double amount = getPositiveDouble();
        if (amount > 0) {
            boolean success = account.withdraw(amount);
            if (!success) {
                System.out.println("Withdrawal failed.");
            }
        } else {
            System.out.println("Withdrawal failed. Amount must be positive.");
        }
    }

    private double getPositiveDouble() {
        double amount = -1;
        try {
            amount = Double.parseDouble(scanner.nextLine());
            if (amount <= 0) {
                System.out.println("Amount must be greater than zero.");
                amount = -1;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a numerical value.");
        }
        return amount;
    }
}
