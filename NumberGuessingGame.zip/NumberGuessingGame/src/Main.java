import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int min = 1;
        int max = 100;
        int maxAttempts = 10;
        int totalScore = 0;
        Scanner scanner = new Scanner(System.in);
        boolean playAgain = true;

        System.out.println("Welcome to the Number Guessing Game!");

        while (playAgain) {
            int randomNumber = generateRandomNumber(min, max);
            int guess = 0;
            int attempts = 0;
            boolean guessedCorrectly = false;

            System.out.println("\nI've picked a number between " + min + " and " + max + ".");
            System.out.println("You have up to " + maxAttempts + " chances to figure it out.");

            while (guess != randomNumber && attempts < maxAttempts) {
                System.out.print("Attempt " + (attempts + 1) + ": What's your guess? ");
                try {
                    guess = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Invalid input. Please enter a whole number.");
                    scanner.next(); 
                    continue;
                }

                attempts++;

                if (guess == randomNumber) {
                    System.out.println("Well done! You guessed the number after " + attempts + " tries.");
                    guessedCorrectly = true;
                } else if (guess < randomNumber) {
                    System.out.println("Your guess is too low.");
                } else {
                    System.out.println("Your guess is too high.");
                }
            }

            if (!guessedCorrectly) {
                System.out.println("Better luck next time! The correct number was " + randomNumber + ".");
            }

            if (guessedCorrectly) {
                int roundScore = 100 - (attempts * 10);
                roundScore = Math.max(roundScore, 0); 
                totalScore += roundScore;
                System.out.println("You earned " + roundScore + " points this round.");
            } else {
                System.out.println("You earned 0 points this round.");
            }

            System.out.println("Your total score is: " + totalScore);
            System.out.print("Would you like to play again? (yes/no): ");
            String response = scanner.next();

            if (!response.equalsIgnoreCase("yes")) {
                playAgain = false;
                System.out.println("Thanks for playing! Your final score is " + totalScore + ".");
            }
        }
        scanner.close();
    }

    public static int generateRandomNumber(int min, int max) {
        Random rand = new Random();
        return rand.nextInt((max - min) + 1) + min;
    }
}
